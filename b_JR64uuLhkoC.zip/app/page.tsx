"use client"

import  from "../src/main"

export default function SyntheticV0PageForDeployment() {
  return < />
}