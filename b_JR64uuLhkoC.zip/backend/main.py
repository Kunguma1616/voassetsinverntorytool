import os
import base64
import json
import logging
from datetime import datetime
from io import BytesIO
from typing import List
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from groq import Groq
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image as RLImage, Table, TableStyle, PageBreak
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.units import inch
from reportlab.lib import colors
from dotenv import load_dotenv

load_dotenv()

# ---------------------------------------------------
# Load API Key
# ---------------------------------------------------
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
if not GROQ_API_KEY:
    raise RuntimeError("Missing GROQ_API_KEY in .env")

# ---------------------------------------------------
# Import YOUR EXACT FUNCTIONS without modifying them
# ---------------------------------------------------
def encode_image_to_base64(uploaded_file):
    uploaded_file.seek(0)
    data = uploaded_file.read()
    return base64.b64encode(data).decode("utf-8"), data

def get_asset_metadata(base64_image, mime_type, api_key):
    client = Groq(api_key=api_key)
    prompt = """You are an expert industrial asset analyzer. Analyze the image of the tool/equipment carefully.

APPROVED ASSET TYPES:
[...]

CRITICAL: Return ONLY valid JSON. For unknown fields, use "Not visible"."""
    
    response = client.chat.completions.create(
        model="meta-llama/llama-4-scout-17b-16e-instruct",
        response_format={"type": "json_object"},
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{base64_image}"}}
                ]
            }
        ],
        max_completion_tokens=2000,
        temperature=0.3
    )
    return json.loads(response.choices[0].message.content)

def create_engineer_pdf_report(engineer_name, engineer_category, assets_data, logo_bytes):
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    story = []
    styles = getSampleStyleSheet()
    
    title_style = ParagraphStyle(
        'ReportTitle',
        parent=styles['Heading1'],
        fontSize=28,
        textColor=colors.HexColor('#27549D'),
        alignment=TA_CENTER,
        fontName='Helvetica-Bold'
    )
    
    story.append(Spacer(1, 0.5 * inch))
    
    if logo_bytes:
        try:
            logo_img = RLImage(BytesIO(logo_bytes), width=1.5 * inch, height=1.5 * inch)
            logo_img.hAlign = 'CENTER'
            story.append(logo_img)
        except:
            pass
    
    story.append(Paragraph("ENGINEER ASSET INVENTORY REPORT", title_style))
    story.append(Spacer(1, 0.3 * inch))
    
    # Add Engineer Info table
    info_table = Table([
        ["Engineer Name:", engineer_name],
        ["Category:", engineer_category],
        ["Total Assets:", str(len(assets_data))],
        ["Date:", datetime.now().strftime("%Y-%m-%d")]
    ], colWidths=[150, 350])
    
    info_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), colors.HexColor("#27549D")),
        ('TEXTCOLOR', (0, 0), (0, -1), colors.white),
        ('GRID', (0, 0), (-1, -1), 1, colors.grey)
    ]))
    
    story.append(info_table)
    story.append(PageBreak())
    
    # Loop Through Assets
    for idx, asset in enumerate(assets_data, 1):
        story.append(Paragraph(f"Asset #{idx}: {asset['filename']}", styles["Heading2"]))
        
        # Add Image
        try:
            img_bytes = base64.b64decode(asset["image_base64"])
            img = RLImage(BytesIO(img_bytes), width=4 * inch, height=3 * inch)
            story.append(img)
        except:
            pass
        
        story.append(Spacer(1, 0.2 * inch))
        
        # Add Metadata Table
        rows = []
        for section, values in asset["metadata"].items():
            if isinstance(values, dict):
                for k, v in values.items():
                    rows.append([k.replace("_", " ").title(), str(v)])
        
        meta_table = Table(rows, colWidths=[200, 300])
        meta_table.setStyle(TableStyle([
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ]))
        story.append(meta_table)
        
        if idx != len(assets_data):
            story.append(PageBreak())
    
    doc.build(story)
    buffer.seek(0)
    return buffer

# ---------------------------------------------------
# FASTAPI APP
# ---------------------------------------------------
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_headers=["*"],
    allow_methods=["*"]
)

# ---------------------------------------------------
# ROUTE 1: IMAGE UPLOAD + METADATA
# ---------------------------------------------------
@app.post("/upload-image")
async def upload_image(image: UploadFile = File(...)):
    try:
        base64_str, img_bytes = encode_image_to_base64(image)
        metadata = get_asset_metadata(base64_str, image.content_type, GROQ_API_KEY)
        return {
            "filename": image.filename,
            "metadata": metadata,
            "image_base64": base64_str
        }
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"error": str(e)}
        )

# ---------------------------------------------------
# ROUTE 2: PDF GENERATION
# ---------------------------------------------------
@app.post("/generate-pdf")
async def generate_pdf(
    engineer_name: str = Form(...),
    engineer_category: str = Form(...),
    assets_json: str = Form(...),
    logo: UploadFile = File(None)
):
    try:
        assets = json.loads(assets_json)
        logo_bytes = logo.file.read() if logo else None
        
        pdf_buffer = create_engineer_pdf_report(
            engineer_name,
            engineer_category,
            assets,
            logo_bytes
        )
        
        filename = f"{engineer_name.replace(' ', '_')}_Report_{datetime.now().strftime('%Y%m%d_%H%M')}.pdf"
        
        return StreamingResponse(
            pdf_buffer,
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"error": str(e)}
        )

@app.get("/")
def home():
    return {"message": "Asset Inventory FastAPI Server Running"}
