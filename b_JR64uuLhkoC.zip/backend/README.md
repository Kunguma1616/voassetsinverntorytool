# Asset Inventory Backend

## Setup Instructions

1. Install Python dependencies:
\`\`\`bash
pip install -r requirements.txt
\`\`\`

2. Create `.env` file:
\`\`\`bash
cp .env.example .env
\`\`\`

3. Add your GROQ API key to `.env`:
\`\`\`
GROQ_API_KEY=your_actual_api_key
\`\`\`

4. Run the server:
\`\`\`bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
\`\`\`

The API will be available at `http://localhost:8000`

## API Endpoints

- `GET /` - Health check
- `POST /upload-image` - Upload asset image and extract metadata
- `POST /generate-pdf` - Generate engineer report PDF
