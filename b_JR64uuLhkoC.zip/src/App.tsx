import { Routes, Route } from "react-router-dom"
import UploadAssets from "./pages/UploadAssets"
import AssetList from "./pages/AssetList"
import GenerateReport from "./pages/GenerateReport"
import { AssetProvider } from "./context/AssetContext"

function App() {
  return (
    <AssetProvider>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
        <Routes>
          <Route path="/" element={<UploadAssets />} />
          <Route path="/assets" element={<AssetList />} />
          <Route path="/report" element={<GenerateReport />} />
        </Routes>
      </div>
    </AssetProvider>
  )
}

export default App
