"use client"

import type React from "react"

import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { Upload, Loader2, FileImage, CheckCircle2, XCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useAssets } from "@/context/AssetContext"
import { uploadImage } from "@/lib/api"
import { toast } from "sonner"

export default function UploadAssets() {
  const navigate = useNavigate()
  const { addAsset, assets } = useAssets()
  const [uploading, setUploading] = useState(false)
  const [selectedFiles, setSelectedFiles] = useState<File[]>([])
  const [previews, setPreviews] = useState<string[]>([])

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    setSelectedFiles(files)

    // Generate previews
    const newPreviews = files.map((file) => URL.createObjectURL(file))
    setPreviews(newPreviews)
  }

  const handleUpload = async () => {
    if (selectedFiles.length === 0) {
      toast.error("Please select at least one image")
      return
    }

    setUploading(true)

    try {
      for (const file of selectedFiles) {
        const result = await uploadImage(file)
        addAsset(result)
        toast.success(`${file.name} analyzed successfully!`)
      }

      // Clear selections
      setSelectedFiles([])
      setPreviews([])

      toast.success("All assets uploaded successfully!")
    } catch (error: any) {
      console.error("[v0] Upload error:", error)
      toast.error(error.response?.data?.error || "Failed to upload images")
    } finally {
      setUploading(false)
    }
  }

  const handleContinue = () => {
    if (assets.length === 0) {
      toast.error("Please upload at least one asset")
      return
    }
    navigate("/assets")
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8 text-center">
        <h1 className="text-4xl font-bold text-slate-900 mb-2">Engineer Asset Inventory</h1>
        <p className="text-slate-600">Upload asset images for AI-powered metadata extraction</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Upload Card */}
        <Card className="border-2 border-dashed border-slate-300 hover:border-blue-400 transition-colors">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5 text-blue-600" />
              Upload Asset Images
            </CardTitle>
            <CardDescription>Select one or multiple images of your engineering assets</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="relative">
              <input
                type="file"
                accept="image/*"
                multiple
                onChange={handleFileSelect}
                className="hidden"
                id="file-upload"
                disabled={uploading}
              />
              <label htmlFor="file-upload">
                <div className="flex flex-col items-center justify-center gap-2 p-8 border-2 border-dashed rounded-lg cursor-pointer hover:bg-slate-50 transition-colors">
                  <FileImage className="h-12 w-12 text-slate-400" />
                  <p className="text-sm font-medium text-slate-700">Click to select images</p>
                  <p className="text-xs text-slate-500">PNG, JPG, JPEG up to 10MB</p>
                </div>
              </label>
            </div>

            {selectedFiles.length > 0 && (
              <div className="space-y-2">
                <p className="text-sm font-medium text-slate-700">Selected: {selectedFiles.length} file(s)</p>
                <div className="grid grid-cols-3 gap-2">
                  {previews.map((preview, idx) => (
                    <div key={idx} className="relative aspect-square rounded-lg overflow-hidden border">
                      <img
                        src={preview || "/placeholder.svg"}
                        alt={selectedFiles[idx].name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            <Button
              onClick={handleUpload}
              disabled={uploading || selectedFiles.length === 0}
              className="w-full bg-blue-600 hover:bg-blue-700"
              size="lg"
            >
              {uploading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Analyzing Assets...
                </>
              ) : (
                <>
                  <Upload className="mr-2 h-4 w-4" />
                  Upload & Analyze
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Status Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
              Upload Status
            </CardTitle>
            <CardDescription>{assets.length} asset(s) processed successfully</CardDescription>
          </CardHeader>
          <CardContent>
            {assets.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <XCircle className="h-16 w-16 text-slate-300 mb-4" />
                <p className="text-slate-500">No assets uploaded yet</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {assets.map((asset, idx) => (
                  <div key={idx} className="flex items-center gap-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                    <CheckCircle2 className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-900 truncate">{asset.filename}</p>
                      <p className="text-xs text-slate-600">Metadata extracted</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {assets.length > 0 && (
              <Button onClick={handleContinue} className="w-full mt-4 bg-slate-900 hover:bg-slate-800" size="lg">
                Continue to Asset List
              </Button>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
