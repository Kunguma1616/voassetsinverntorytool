"use client"

import type React from "react"

import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { FileText, Loader2, Download, ArrowLeft, UploadIcon } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useAssets } from "@/context/AssetContext"
import { generatePDF } from "@/lib/api"
import { toast } from "sonner"

export default function GenerateReport() {
  const navigate = useNavigate()
  const { assets } = useAssets()
  const [engineerName, setEngineerName] = useState("")
  const [engineerCategory, setEngineerCategory] = useState("")
  const [logo, setLogo] = useState<File | null>(null)
  const [logoPreview, setLogoPreview] = useState<string>("")
  const [generating, setGenerating] = useState(false)

  const handleLogoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setLogo(file)
      const preview = URL.createObjectURL(file)
      setLogoPreview(preview)
    }
  }

  const handleGenerate = async () => {
    if (!engineerName.trim()) {
      toast.error("Please enter engineer name")
      return
    }

    if (!engineerCategory) {
      toast.error("Please select engineer category")
      return
    }

    if (assets.length === 0) {
      toast.error("No assets available. Please upload assets first.")
      navigate("/")
      return
    }

    setGenerating(true)

    try {
      const pdfBlob = await generatePDF(engineerName, engineerCategory, assets, logo)

      // Download the PDF
      const url = window.URL.createObjectURL(pdfBlob)
      const a = document.createElement("a")
      a.href = url
      a.download = `${engineerName.replace(/ /g, "_")}_Report_${new Date().toISOString().slice(0, 10)}.pdf`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)

      toast.success("PDF report generated successfully!")
    } catch (error: any) {
      console.error("[v0] PDF generation error:", error)
      toast.error(error.response?.data?.error || "Failed to generate PDF")
    } finally {
      setGenerating(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-8">
        <Button onClick={() => navigate("/assets")} variant="outline" className="mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Assets
        </Button>
        <h1 className="text-4xl font-bold text-slate-900 mb-2">Generate Engineer Report</h1>
        <p className="text-slate-600">Fill in the details to create your PDF inventory report</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Form Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-blue-600" />
              Report Information
            </CardTitle>
            <CardDescription>Enter engineer and project details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="engineer-name">Engineer Name *</Label>
              <Input
                id="engineer-name"
                placeholder="John Smith"
                value={engineerName}
                onChange={(e) => setEngineerName(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="engineer-category">Engineer Category *</Label>
              <Select value={engineerCategory} onValueChange={setEngineerCategory}>
                <SelectTrigger id="engineer-category">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Mechanical Engineer">Mechanical Engineer</SelectItem>
                  <SelectItem value="Electrical Engineer">Electrical Engineer</SelectItem>
                  <SelectItem value="Civil Engineer">Civil Engineer</SelectItem>
                  <SelectItem value="Industrial Engineer">Industrial Engineer</SelectItem>
                  <SelectItem value="Maintenance Engineer">Maintenance Engineer</SelectItem>
                  <SelectItem value="Field Engineer">Field Engineer</SelectItem>
                  <SelectItem value="Project Engineer">Project Engineer</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="logo-upload">Company Logo (Optional)</Label>
              <div className="relative">
                <input type="file" accept="image/*" onChange={handleLogoSelect} className="hidden" id="logo-upload" />
                <label htmlFor="logo-upload">
                  <div className="flex items-center gap-2 p-3 border-2 border-dashed rounded-lg cursor-pointer hover:bg-slate-50 transition-colors">
                    <UploadIcon className="h-5 w-5 text-slate-400" />
                    <span className="text-sm text-slate-600">{logo ? logo.name : "Click to upload logo"}</span>
                  </div>
                </label>
              </div>
              {logoPreview && (
                <div className="mt-2 p-2 border rounded-lg bg-slate-50">
                  <img
                    src={logoPreview || "/placeholder.svg"}
                    alt="Logo preview"
                    className="h-20 object-contain mx-auto"
                  />
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Summary Card */}
        <Card>
          <CardHeader>
            <CardTitle>Report Summary</CardTitle>
            <CardDescription>Review your report details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-blue-50 rounded-lg space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-slate-700">Engineer:</span>
                <span className="text-sm text-slate-900">{engineerName || "Not set"}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-slate-700">Category:</span>
                <span className="text-sm text-slate-900">{engineerCategory || "Not set"}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-slate-700">Total Assets:</span>
                <span className="text-sm font-bold text-blue-600">{assets.length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-slate-700">Company Logo:</span>
                <span className="text-sm text-slate-900">{logo ? "Included" : "Not included"}</span>
              </div>
            </div>

            <div className="pt-4 space-y-2">
              <p className="text-sm text-slate-600">The generated PDF report will include:</p>
              <ul className="text-sm text-slate-600 space-y-1 list-disc list-inside">
                <li>Engineer information and credentials</li>
                <li>All {assets.length} asset(s) with images</li>
                <li>Complete metadata for each asset</li>
                <li>Professional formatting and layout</li>
              </ul>
            </div>

            <Button
              onClick={handleGenerate}
              disabled={generating}
              className="w-full bg-green-600 hover:bg-green-700"
              size="lg"
            >
              {generating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating PDF...
                </>
              ) : (
                <>
                  <Download className="mr-2 h-4 w-4" />
                  Generate & Download PDF
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
