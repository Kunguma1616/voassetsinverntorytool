"use client"

import { useNavigate } from "react-router-dom"
import { Trash2, FileText, ArrowRight, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useAssets } from "@/context/AssetContext"
import { toast } from "sonner"

export default function AssetList() {
  const navigate = useNavigate()
  const { assets, removeAsset } = useAssets()

  const handleRemove = (index: number) => {
    removeAsset(index)
    toast.success("Asset removed")
  }

  const handleContinue = () => {
    if (assets.length === 0) {
      toast.error("Please upload at least one asset")
      navigate("/")
      return
    }
    navigate("/report")
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-4xl font-bold text-slate-900 mb-2">Asset Inventory</h1>
            <p className="text-slate-600">Review and manage your uploaded assets</p>
          </div>
          <Badge variant="secondary" className="text-lg px-4 py-2">
            {assets.length} Asset{assets.length !== 1 ? "s" : ""}
          </Badge>
        </div>

        <div className="flex gap-3">
          <Button onClick={() => navigate("/")} variant="outline" size="lg">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Upload More
          </Button>
          <Button
            onClick={handleContinue}
            disabled={assets.length === 0}
            className="bg-blue-600 hover:bg-blue-700"
            size="lg"
          >
            Generate Report
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>

      {assets.length === 0 ? (
        <Card className="border-2 border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <FileText className="h-16 w-16 text-slate-300 mb-4" />
            <p className="text-lg font-medium text-slate-900 mb-2">No assets found</p>
            <p className="text-slate-500 mb-4">Upload some assets to get started</p>
            <Button onClick={() => navigate("/")}>Go to Upload</Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {assets.map((asset, idx) => (
            <Card key={idx} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="aspect-video relative bg-slate-100">
                <img
                  src={`data:image/jpeg;base64,${asset.image_base64}`}
                  alt={asset.filename}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-2 right-2">
                  <Button onClick={() => handleRemove(idx)} variant="destructive" size="icon" className="h-8 w-8">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg truncate">{asset.filename}</CardTitle>
                <CardDescription>Asset #{idx + 1}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {Object.entries(asset.metadata)
                    .slice(0, 3)
                    .map(([key, value]) => {
                      if (typeof value === "object" && value !== null) {
                        const firstEntry = Object.entries(value)[0]
                        if (firstEntry) {
                          return (
                            <div key={key} className="text-sm">
                              <span className="font-medium text-slate-700">
                                {String(firstEntry[0]).replace(/_/g, " ")}:
                              </span>{" "}
                              <span className="text-slate-600">{String(firstEntry[1])}</span>
                            </div>
                          )
                        }
                      }
                      return (
                        <div key={key} className="text-sm">
                          <span className="font-medium text-slate-700">{key.replace(/_/g, " ")}:</span>{" "}
                          <span className="text-slate-600">{String(value)}</span>
                        </div>
                      )
                    })}
                  <p className="text-xs text-slate-500 pt-2">+ more metadata available</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
