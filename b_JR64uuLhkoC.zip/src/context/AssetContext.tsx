"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

export interface Asset {
  filename: string
  metadata: Record<string, any>
  image_base64: string
}

interface AssetContextType {
  assets: Asset[]
  addAsset: (asset: Asset) => void
  removeAsset: (index: number) => void
  clearAssets: () => void
}

const AssetContext = createContext<AssetContextType | undefined>(undefined)

export function AssetProvider({ children }: { children: ReactNode }) {
  const [assets, setAssets] = useState<Asset[]>([])

  const addAsset = (asset: Asset) => {
    setAssets((prev) => [...prev, asset])
  }

  const removeAsset = (index: number) => {
    setAssets((prev) => prev.filter((_, i) => i !== index))
  }

  const clearAssets = () => {
    setAssets([])
  }

  return (
    <AssetContext.Provider value={{ assets, addAsset, removeAsset, clearAssets }}>{children}</AssetContext.Provider>
  )
}

export function useAssets() {
  const context = useContext(AssetContext)
  if (context === undefined) {
    throw new Error("useAssets must be used within an AssetProvider")
  }
  return context
}
