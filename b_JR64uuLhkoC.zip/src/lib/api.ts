import axios from "axios"

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:8000"

const api = axios.create({
  baseURL: API_URL,
})

export interface UploadImageResponse {
  filename: string
  metadata: Record<string, any>
  image_base64: string
}

export async function uploadImage(file: File): Promise<UploadImageResponse> {
  const formData = new FormData()
  formData.append("image", file)

  const response = await api.post<UploadImageResponse>("/upload-image", formData, {
    headers: {
      "Content-Type": "multipart/form-data",
    },
  })

  return response.data
}

export async function generatePDF(
  engineerName: string,
  engineerCategory: string,
  assets: any[],
  logo: File | null,
): Promise<Blob> {
  const formData = new FormData()
  formData.append("engineer_name", engineerName)
  formData.append("engineer_category", engineerCategory)
  formData.append("assets_json", JSON.stringify(assets))

  if (logo) {
    formData.append("logo", logo)
  }

  const response = await api.post("/generate-pdf", formData, {
    responseType: "blob",
    headers: {
      "Content-Type": "multipart/form-data",
    },
  })

  return response.data
}
